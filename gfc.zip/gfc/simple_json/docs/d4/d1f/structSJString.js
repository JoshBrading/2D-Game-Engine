var structSJString =
[
    [ "size", "d4/d1f/structSJString.html#aadeb1114b35655389566beaab06d43d5", null ],
    [ "text", "d4/d1f/structSJString.html#a623eb7be189beccc29815162623ef0ca", null ]
];