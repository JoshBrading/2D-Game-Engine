var structSJPair =
[
    [ "key", "dd/d6d/structSJPair.html#a23681f167b9eac4d55be408c2007ae6c", null ],
    [ "value", "dd/d6d/structSJPair.html#aeee74c0e0e05940043b8aa96d1be43a4", null ]
];