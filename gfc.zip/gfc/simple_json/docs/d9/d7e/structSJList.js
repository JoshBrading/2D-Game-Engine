var structSJList =
[
    [ "count", "d9/d7e/structSJList.html#a706017d74f3cde16157127d8e8025116", null ],
    [ "elements", "d9/d7e/structSJList.html#a43fc72ebe9774607d3c503917b911c7c", null ],
    [ "size", "d9/d7e/structSJList.html#a1e3944d88b5e2aac09698498f376559b", null ]
];