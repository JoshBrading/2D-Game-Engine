var structjsParse =
[
    [ "buffer", "d9/dd9/structjsParse.html#a9c0b007595634aae8cdb98a7a85b846a", null ],
    [ "end", "d9/dd9/structjsParse.html#aa9b5c5a2d56b1753ccadf84c00385fba", null ],
    [ "position", "d9/dd9/structjsParse.html#ace05b203435af05113a9a4b7c40f0324", null ]
];