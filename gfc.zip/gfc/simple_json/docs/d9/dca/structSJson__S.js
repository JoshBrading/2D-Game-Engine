var structSJson__S =
[
    [ "array", "d9/dca/structSJson__S.html#aa8c595b7789550a64b08950b0ad88e1e", null ],
    [ "copy", "d9/dca/structSJson__S.html#a3910fed04a197e779815cad2b0535f62", null ],
    [ "get_string", "d9/dca/structSJson__S.html#afd320740fab795e7063e89157a23c511", null ],
    [ "json_free", "d9/dca/structSJson__S.html#a8bd24b6b85325a01b8bae6c5899583f2", null ],
    [ "sjtype", "d9/dca/structSJson__S.html#ad68edc13b2a814f9b920498ba439b8ba", null ],
    [ "string", "d9/dca/structSJson__S.html#ab50f7c395b214eb050ff59e3a9bbeb4a", null ],
    [ "v", "d9/dca/structSJson__S.html#a34c41be372d7bbe614b312cef2051b99", null ]
];