var simple__json__error_8c =
[
    [ "sj_get_error", "d8/d02/simple__json__error_8c.html#a5d74fc3dd2997bd985966f6c31e241de", null ],
    [ "sj_set_error", "d8/d02/simple__json__error_8c.html#ae0819d6f58f423e5d26ea66df15de81c", null ]
];