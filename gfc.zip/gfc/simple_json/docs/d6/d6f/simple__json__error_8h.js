var simple__json__error_8h =
[
    [ "false", "d6/d6f/simple__json__error_8h.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "MAX", "d6/d6f/simple__json__error_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MIN", "d6/d6f/simple__json__error_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "true", "d6/d6f/simple__json__error_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "sj_get_error", "d6/d6f/simple__json__error_8h.html#a5d74fc3dd2997bd985966f6c31e241de", null ],
    [ "sj_set_error", "d6/d6f/simple__json__error_8h.html#a6cbf23366a99bf9b2d5ec4a39cc05d23", null ]
];