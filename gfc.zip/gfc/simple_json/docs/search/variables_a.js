var searchData=
[
  ['text',['text',['../d4/d1f/structSJString.html#a623eb7be189beccc29815162623ef0ca',1,'SJString']]]
];
