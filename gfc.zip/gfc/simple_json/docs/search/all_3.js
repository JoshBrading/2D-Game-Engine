var searchData=
[
  ['data',['data',['../d0/d8b/structSJListElementData.html#ae48c7175a4477eb042b02b70c88485d1',1,'SJListElementData']]]
];
