var searchData=
[
  ['get_5fstring',['get_string',['../d9/dca/structSJson__S.html#afd320740fab795e7063e89157a23c511',1,'SJson_S']]]
];
