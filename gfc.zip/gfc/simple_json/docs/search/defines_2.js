var searchData=
[
  ['true',['true',['../d6/d6f/simple__json__error_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7',1,'simple_json_error.h']]]
];
