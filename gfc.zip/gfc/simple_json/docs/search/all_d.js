var searchData=
[
  ['text',['text',['../d4/d1f/structSJString.html#a623eb7be189beccc29815162623ef0ca',1,'SJString']]],
  ['true',['true',['../d6/d6f/simple__json__error_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7',1,'simple_json_error.h']]]
];
